import type { StrategyModule } from "../index.js";

export const strategy: StrategyModule = {
  id: "mtfAlignment",
  kind: "long",
  evaluate(ctx) {
    const { candles, bundle } = ctx;
    const runtime = (ctx as { runtime?: { volumeThresholdUSD?: number; maxAtrPct?: number; priceTick?: number } }).runtime;
    const n = candles.length;
    if (n < 220) return [];                            // ensure enough history
    const i = n - 1;

    // --- Data shortcuts (CLOSE ONLY ON CLOSED BAR) ---
    const close = bundle.closes[i];
    const ema20 = bundle.ema[20]?.[i];
    const ema50 = bundle.ema[50]?.[i];
    const atr14 = bundle.atr14?.[i] ?? 0;
    if (!ema20 || !ema50 || atr14 <= 0) return [];

    // --- Engine-wide guardrails ---
    // Liquidity: dollar-volume
    const vol = bundle.volumes?.[i] ?? 0;
    const dollarVol = close * vol;
    const volThresh = runtime?.volumeThresholdUSD ?? 1_000_000; // set in EngineRuntimeConfig
    if (dollarVol < volThresh) return [];

    // Volatility cap (avoid blowout stops)
    const maxAtrPct = runtime?.maxAtrPct ?? 0.07;      // 7% default
    if (atr14 / close > maxAtrPct) return [];

    // OPTIONAL: earnings/gap veto if your bundle exposes it
    // if (bundle.earnings?.withinNDays?.[i] <= 3) return [];
    // const gapPct = Math.abs(candles[i].open - bundle.closes[i-1]) / bundle.closes[i-1];
    // if (gapPct > 0.04) return []; // skip giant gaps

    // --- LTF trend alignment ---
    if (!(close > ema20 && close > ema50)) return [];

    // --- TRUE MTF: confirm with higher timeframe EMA (if available) ---
    const htfBundle = (bundle as { htf?: { ema50?: Array<number | undefined> } }).htf;
    const htfEma50 = htfBundle?.ema50?.[i]; // e.g., 4H or 1D per your resampler
    if (htfEma50 != null && !(close > htfEma50)) return [];

    // --- Structure: HH/HL windows (no current-bar lookahead) ---
    const highs = bundle.highs, lows = bundle.lows;
    const win = 10; // swing window
    const recentHigh = Math.max(...highs.slice(i - win, i));
    const prevHigh = Math.max(...highs.slice(i - 2 * win, i - win));
    const recentLow = Math.min(...lows.slice(i - win, i));
    const prevLow = Math.min(...lows.slice(i - 2 * win, i - win));

    if (!(recentHigh > prevHigh && recentLow > prevLow)) return [];

    // --- Trigger: break + close above the recentHigh (reduces shallow/bad entries) ---
    if (!(close > recentHigh)) return [];

    // --- Stop: farther of structure low and ATR stop ---
    const atrStop = close - 1.0 * atr14;
    const structureStop = recentLow;
    const stop = Math.min(structureStop, atrStop);

    // Safety: ensure stop is below current low by a minimum tick
    const pxTick = runtime?.priceTick ?? 0.01;
    if (!(stop < candles[i].low - pxTick)) return [];

    // --- Target: 2R from entry price (in PRICE units) ---
    const risk = close - stop;
    const firstTarget = close + 2.0 * risk;

    // --- Scoring factors (optional gates) ---
    const bbWidthRankOK = bundle.bb?.widthRank120?.[i] == null || bundle.bb.widthRank120[i] <= 60;
    const volExpandOK = (bundle.volMA20?.[i] ?? 1) > 0 ? vol >= 1.3 * (bundle.volMA20[i] ?? 1) : true;
    const macdUpOK = bundle.macd?.hist?.[i] != null && bundle.macd.hist[i] > bundle.macd.hist[i - 1];

    if (!bbWidthRankOK || !volExpandOK || !macdUpOK) return [];

    return [{
      id: "mtfAlignment",
      kind: "long",
      name: "MTF Alignment",
      side: "LONG",
      entry: close,                  // <-- price units
      stop,                          // <-- price units
      firstTarget,                   // <-- price units
      timestamp: candles[i].ts,
      tags: ["mtfAlignment"],
      reasons: ["ema20/50 up", "HTF ok", "HH/HL", "Break recentHigh", "ATR/Liq ok"],
      strategyFactors: [
        { name: "bbWidthLow",  hit: bbWidthRankOK },
        { name: "volumeSpike", hit: volExpandOK },
        { name: "macdHistUp",  hit: macdUpOK }
      ],
      notes: "Entry gated by breakout; conservative stop; 2R target."
    }];
  }
};
